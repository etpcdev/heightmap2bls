datablock fxDTSBrickData (brick4x4x6Data)
{
	brickFile = "./4x4x6.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "4x4 2brick";
	iconName = "Add-Ons/Brick_4n8brickH/4xicon";
};

datablock fxDTSBrickData (brick4x4x9Data)
{
	brickFile = "./4x4x9.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "4x4 3brick";
	iconName = "Add-Ons/Brick_4n8brickH/4xicon";
};

datablock fxDTSBrickData (brick4x4x12Data)
{
	brickFile = "./4x4x12.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "4x4 4brick";
	iconName = "Add-Ons/Brick_4n8brickH/4xicon";
};

datablock fxDTSBrickData (brick4x4x15Data)
{
	brickFile = "./4x4x15.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "4x4 5brick";
	iconName = "Add-Ons/Brick_4n8brickH/4xicon";
};

datablock fxDTSBrickData (brick8x8x6Data)
{
	brickFile = "./8x8x6.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "8x8 2brick";
	iconName = "Add-Ons/Brick_4n8brickH/8xicon";
};

datablock fxDTSBrickData (brick8x8x9Data)
{
	brickFile = "./8x8x9.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "8x8 3brick";
	iconName = "Add-Ons/Brick_4n8brickH/8xicon";
};

datablock fxDTSBrickData (brick8x8x12Data)
{
	brickFile = "./8x8x12.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "8x8 4brick";
	iconName = "Add-Ons/Brick_4n8brickH/8xicon";
};

datablock fxDTSBrickData (brick8x8x15Data)
{
	brickFile = "./8x8x15.blb";
	category = "Bricks";
	subCategory = "MiniTerrain";
	uiName = "8x8 5brick";
	iconName = "Add-Ons/Brick_4n8brickH/8xicon";
};
