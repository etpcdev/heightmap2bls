datablock fxDTSBrickData (brick4x4x90Data)
{
	brickFile = "./4x4x90.blb";
	category = "Bricks";
	subCategory = "MTT";
	uiName = "4x4 30brick";
	iconName = "Add-Ons/Brick_4n8brickT/4xicon";
	CollisionShapeName = "Add-Ons/Brick_4n8brickT/4x4x90.dts";
};

datablock fxDTSBrickData (brick8x8x90Data)
{
	brickFile = "./8x8x90.blb";
	category = "Bricks";
	subCategory = "MTT";
	uiName = "8x8 30brick";
	iconName = "Add-Ons/Brick_4n8brickT/8xicon";
	CollisionShapeName = "Add-Ons/Brick_4n8brickT/8x8x90.dts";
};

datablock fxDTSBrickData (brick16x16x90Data)
{
	brickFile = "./16x16x90.blb";
	category = "Bricks";
	subCategory = "MTT";
	uiName = "16x16 30brick";
	iconName = "Add-Ons/Brick_4n8brickT/8xicon";
	CollisionShapeName = "Add-Ons/Brick_4n8brickT/16x16x90.dts";
};
